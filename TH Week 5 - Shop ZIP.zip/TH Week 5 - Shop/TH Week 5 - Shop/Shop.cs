﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace TH_Week_5___Shop
{
    public partial class Shop : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtCategory;
        DataTable dtProdukTampil;
        List<string> uniqueCategoryValues = new List<string>();
        public Shop()
        {
            InitializeComponent();
        }

        private void Shop_Load(object sender, EventArgs e)
        {
            btn_AddCategory.BackColor = Color.Lime;
            btn_RemoveCategory.BackColor = Color.Red;

            btn_AddProduct.BackColor = Color.Lime;
            btn_EditProduct.BackColor = Color.Yellow;
            btn_RemoveProduct.BackColor = Color.Red;

            dataGridView_Product.RowTemplate.Height = 18;
            dataGridView_Product.ColumnHeadersHeight = 18;


            dataGridView_Category.RowTemplate.Height = 23;
            dataGridView_Category.ColumnHeadersHeight = 23;

            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            dataGridView_Product.DataSource = dtProdukSimpan;

            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dataGridView_Category.DataSource = dtCategory;

            dtProdukTampil = new DataTable();
       

            comboBox_CategoryDetails.Items.Clear();
            uniqueCategoryValues.Clear();
            foreach (DataGridViewRow row in dataGridView_Category.Rows)
            {
                if (row.Cells["Nama Category"].Value != null && !uniqueCategoryValues.Contains(row.Cells["Nama Category"].Value.ToString()))
                {
                    uniqueCategoryValues.Add(row.Cells["Nama Category"].Value.ToString());
                    comboBox_CategoryDetails.Items.Add(row.Cells["Nama Category"].Value.ToString());
                }
            }
            dataGridView_Category.ClearSelection();
            dataGridView_Product.ClearSelection();
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            string dataNamaCategory = tBox_NamaCategory.Text;

            if (dataNamaCategory == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu", "Error");
            }
            else
            {
                bool test = false;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dataNamaCategory == dtCategory.Rows[i][1].ToString())
                    {
                        MessageBox.Show("Nama category sudah ada", "Ga bisa");
                        test = true;
                        break;
                    }
                }

                if (test == false)
                {
                    int angkaID = 1;
                    foreach (DataRow row in dtCategory.Rows)
                    {
                        int currentID = int.Parse(row[0].ToString().Substring(1));
                        if (currentID >= angkaID)
                        {
                            angkaID = currentID + 1;
                        }
                    }

                    comboBox_BuatFilter.Items.Add(dataNamaCategory);
                    comboBox_CategoryDetails.Items.Add(dataNamaCategory);
                    tBox_NamaCategory.Clear();
                    dtCategory.Rows.Add("C" + angkaID, dataNamaCategory);
                }
            }
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (dataGridView_Category.SelectedRows.Count == 1)
            {
                DataGridViewRow dgvrCategory = dataGridView_Category.CurrentRow;
                DataGridViewRow dgvrProduct = dataGridView_Product.CurrentRow;

                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    dtProdukSimpan.Rows[i][4].ToString();
                    break;
                }

                string simpan = "";
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dgvrCategory.Cells[0].Value.ToString() == dtProdukSimpan.Rows[i][4].ToString())
                    {
                        simpan = dtProdukSimpan.Rows[i][4].ToString();
                    }
                }

                for (int j = dtProdukSimpan.Rows.Count - 1; j >= 0; j--)
                {
                    if (simpan == dtProdukSimpan.Rows[j][4].ToString())
                    {
                        dtProdukSimpan.Rows.Remove(dtProdukSimpan.Rows[j]);
                    }
                }

                comboBox_CategoryDetails.Items.Remove(dgvrCategory.Cells[1].Value.ToString());
                comboBox_BuatFilter.Items.Remove(dgvrCategory.Cells[1].Value.ToString());
                dataGridView_Category.Rows.Remove(dgvrCategory);
                tBox_NamaCategory.Clear();
                dataGridView_Product.ClearSelection();
                dataGridView_Category.ClearSelection();
            }
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            string dataNamaDetails = tBox_NamaDetails.Text;
            string dataCategoryDetails = comboBox_CategoryDetails.Text;
            string dataHargaDetails = tBox_HargaDetails.Text;
            string dataStockDetails = tBox_StockDetails.Text;


            if (dataNamaDetails == "" || dataHargaDetails == "" || dataStockDetails == "")
            {
                MessageBox.Show("Input yang lengkap ya", "Error");
            }
            else if (dataCategoryDetails == "")
            {
                MessageBox.Show("Pilih category dulu boi", "Error");
            }
            else
            {
                int tambah = 0;
                string IDCategory = "";

                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (comboBox_CategoryDetails.Text == dtCategory.Rows[i][1].ToString())
                    {
                        IDCategory = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }

                string productID = "";
                for (int j = dtProdukSimpan.Rows.Count - 1; j >= 0; j--)
                {
                    if (tBox_NamaDetails.Text.Substring(0, 1).ToUpper() == dtProdukSimpan.Rows[j][1].ToString().Substring(0, 1).ToUpper())
                    {
                        string angka = dtProdukSimpan.Rows[j][0].ToString().Substring(1, 3);
                        tambah = Convert.ToInt32(angka) + 1;
                        break;
                    }
                }
                if (tambah < 100)
                {
                     productID = tBox_NamaDetails.Text.Substring(0, 1).ToUpper() + "00" + (tambah).ToString();
                }
                else if (tambah < 10)
                {
                    productID = tBox_NamaDetails.Text.Substring(0, 1).ToUpper() + "0" + (tambah).ToString();
                }
                else
                {
                    productID = tBox_NamaDetails.Text.Substring(0, 1).ToUpper() + (tambah).ToString();
                }
                dtProdukSimpan.Rows.Add(productID, dataNamaDetails, dataHargaDetails, dataStockDetails, IDCategory);

                tBox_NamaDetails.Text = "";
                comboBox_CategoryDetails.Text = "";
                tBox_HargaDetails.Text = "";
                tBox_StockDetails.Text = "";

                dataGridView_Product.ClearSelection();
            }
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (dataGridView_Product.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView_Product.SelectedRows[0].Index;

                string editedProductName = tBox_NamaDetails.Text;
                decimal editedHarga = decimal.Parse(tBox_HargaDetails.Text);
                int editedStock = int.Parse(tBox_StockDetails.Text);

                string editedCategory = "";

                DataRow selectedRow = dtProdukSimpan.Rows[selectedIndex];
                selectedRow["Nama Product"] = editedProductName;
                selectedRow["Harga"] = editedHarga;
                selectedRow["Stock"] = editedStock;

                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == comboBox_CategoryDetails.SelectedItem.ToString())
                    {
                        selectedRow["ID Category"] = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }

                if (editedStock == 0)
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndex);
                }

                dataGridView_Product.Refresh();

                tBox_NamaDetails.Text = "";
                comboBox_CategoryDetails.SelectedIndex = -1;
                tBox_HargaDetails.Text = "";
                tBox_StockDetails.Text = "";
            }
            else
            {
                MessageBox.Show("Pilih produk yang mau diedit terlebih dahulu.", "Error");
            }
            dataGridView_Product.ClearSelection();
            dataGridView_Category.ClearSelection();
        }

        private void dataGridView_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_Product.CurrentRow;
            tBox_NamaDetails.Text = dgvr.Cells[1].Value.ToString();
            tBox_HargaDetails.Text = dgvr.Cells[2].Value.ToString();
            tBox_StockDetails.Text = dgvr.Cells[3].Value.ToString();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == dgvr.Cells[4].Value.ToString())
                {
                    comboBox_CategoryDetails.Text = dtCategory.Rows[i][1].ToString();
                    break;
                }
            }
        }

        private void dataGridView_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_Category.CurrentRow;
            tBox_NamaCategory.Text = dgvr.Cells[1].Value.ToString();
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                dataGridView_Category.Rows[e.RowIndex].Selected = true;
            }
        }

        private void dataGridView_Category_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                dataGridView_Category.Rows[e.RowIndex].Selected = true;
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            comboBox_BuatFilter.Enabled = true;
            comboBox_BuatFilter.Items.Clear();
            PopulateComboBoxWithUniqueValues();
        }

        private void PopulateComboBoxWithUniqueValues()
        {
            uniqueCategoryValues.Clear();
            foreach (DataGridViewRow row in dataGridView_Category.Rows)
            {
                if (row.Cells["Nama Category"].Value != null && !uniqueCategoryValues.Contains(row.Cells["Nama Category"].Value.ToString()))
                {
                    uniqueCategoryValues.Add(row.Cells["Nama Category"].Value.ToString());
                    comboBox_BuatFilter.Items.Add(row.Cells["Nama Category"].Value.ToString());
                }
            }
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_Product.CurrentRow;
            if (dataGridView_Product.SelectedRows.Count == 1)
            {
                if (dataGridView_Product.CurrentRow != null)
                {
                    for (int i = 0; i < dtProdukSimpan.Columns.Count; i++)
                    {
                        for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                        {
                            if (dgvr.Cells[0].Value.ToString() == dtProdukSimpan.Rows[j][0].ToString())
                            {
                                dtProdukSimpan.Rows.RemoveAt(j);
                                dataGridView_Product.Rows.Remove(dataGridView_Product.CurrentRow);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            tBox_NamaDetails.Clear();
            tBox_HargaDetails.Clear();
            tBox_StockDetails.Clear();
            comboBox_CategoryDetails.Text = null;
            comboBox_BuatFilter.Text = null;
            dataGridView_Product.ClearSelection();
            dataGridView_Product.Update();
        }

        private void comboBox_BuatFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_BuatFilter.SelectedItem != null)
            {
                string simpan = "";
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (comboBox_BuatFilter.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        simpan = dtCategory.Rows[i][0].ToString();
                    }
                }

                dtProdukTampil = new DataTable();
                dtProdukTampil.Columns.Add("ID Product");
                dtProdukTampil.Columns.Add("Nama Product");
                dtProdukTampil.Columns.Add("Harga");
                dtProdukTampil.Columns.Add("Stock");
                dtProdukTampil.Columns.Add("ID Category");

                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    if (simpan == dtProdukSimpan.Rows[j][4].ToString())
                    {
                        dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[j][0], dtProdukSimpan.Rows[j][1], dtProdukSimpan.Rows[j][2], dtProdukSimpan.Rows[j][3], dtProdukSimpan.Rows[j][4]);
                    }
                }

                dataGridView_Product.DataSource = dtProdukTampil;
                dataGridView_Product.ClearSelection();
                dataGridView_Category.ClearSelection();
            }
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            dataGridView_Product.DataSource = dtProdukSimpan;
            dataGridView_Product.ClearSelection();
            dataGridView_Category.ClearSelection();
            tBox_NamaDetails.Clear();
            tBox_HargaDetails.Clear();
            tBox_StockDetails.Clear();
            comboBox_CategoryDetails.Text = null;
            comboBox_BuatFilter.Enabled = false;
            tBox_NamaCategory.Clear();
        }

        private void tBox_HargaDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }
    }
}

