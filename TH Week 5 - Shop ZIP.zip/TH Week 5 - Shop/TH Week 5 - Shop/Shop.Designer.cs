﻿namespace TH_Week_5___Shop
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.lbl_Product = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            this.dataGridView_Product = new System.Windows.Forms.DataGridView();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.comboBox_BuatFilter = new System.Windows.Forms.ComboBox();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.dataGridView_Category = new System.Windows.Forms.DataGridView();
            this.lbl_NamaCategory = new System.Windows.Forms.Label();
            this.tBox_NamaCategory = new System.Windows.Forms.TextBox();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.lbl_Details = new System.Windows.Forms.Label();
            this.lbl_NamaDetails = new System.Windows.Forms.Label();
            this.lbl_CategoryDetails = new System.Windows.Forms.Label();
            this.lbl_HargaDetails = new System.Windows.Forms.Label();
            this.lbl_StockDetails = new System.Windows.Forms.Label();
            this.tBox_NamaDetails = new System.Windows.Forms.TextBox();
            this.comboBox_CategoryDetails = new System.Windows.Forms.ComboBox();
            this.tBox_HargaDetails = new System.Windows.Forms.TextBox();
            this.tBox_StockDetails = new System.Windows.Forms.TextBox();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.pictureBox_Molang = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Molang)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Product
            // 
            this.lbl_Product.AutoSize = true;
            this.lbl_Product.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product.Location = new System.Drawing.Point(43, 35);
            this.lbl_Product.Name = "lbl_Product";
            this.lbl_Product.Size = new System.Drawing.Size(144, 42);
            this.lbl_Product.TabIndex = 0;
            this.lbl_Product.Text = "Product";
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(397, 55);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(85, 34);
            this.btn_All.TabIndex = 1;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // dataGridView_Product
            // 
            this.dataGridView_Product.AllowUserToAddRows = false;
            this.dataGridView_Product.AllowUserToDeleteRows = false;
            this.dataGridView_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Product.Location = new System.Drawing.Point(49, 107);
            this.dataGridView_Product.Name = "dataGridView_Product";
            this.dataGridView_Product.ReadOnly = true;
            this.dataGridView_Product.RowHeadersVisible = false;
            this.dataGridView_Product.RowHeadersWidth = 82;
            this.dataGridView_Product.RowTemplate.Height = 33;
            this.dataGridView_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Product.Size = new System.Drawing.Size(707, 390);
            this.dataGridView_Product.TabIndex = 2;
            this.dataGridView_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Product_CellClick);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(488, 54);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(85, 35);
            this.btn_Filter.TabIndex = 3;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // comboBox_BuatFilter
            // 
            this.comboBox_BuatFilter.Enabled = false;
            this.comboBox_BuatFilter.FormattingEnabled = true;
            this.comboBox_BuatFilter.Location = new System.Drawing.Point(579, 56);
            this.comboBox_BuatFilter.Name = "comboBox_BuatFilter";
            this.comboBox_BuatFilter.Size = new System.Drawing.Size(177, 33);
            this.comboBox_BuatFilter.TabIndex = 4;
            this.comboBox_BuatFilter.SelectedIndexChanged += new System.EventHandler(this.comboBox_BuatFilter_SelectedIndexChanged);
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.Location = new System.Drawing.Point(845, 35);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(163, 42);
            this.lbl_Category.TabIndex = 5;
            this.lbl_Category.Text = "Category";
            // 
            // dataGridView_Category
            // 
            this.dataGridView_Category.AllowUserToAddRows = false;
            this.dataGridView_Category.AllowUserToDeleteRows = false;
            this.dataGridView_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Category.Location = new System.Drawing.Point(852, 107);
            this.dataGridView_Category.Name = "dataGridView_Category";
            this.dataGridView_Category.ReadOnly = true;
            this.dataGridView_Category.RowHeadersVisible = false;
            this.dataGridView_Category.RowHeadersWidth = 82;
            this.dataGridView_Category.RowTemplate.Height = 33;
            this.dataGridView_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Category.Size = new System.Drawing.Size(405, 303);
            this.dataGridView_Category.TabIndex = 6;
            this.dataGridView_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Category_CellClick);
            this.dataGridView_Category.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Category_CellDoubleClick);
            // 
            // lbl_NamaCategory
            // 
            this.lbl_NamaCategory.AutoSize = true;
            this.lbl_NamaCategory.Location = new System.Drawing.Point(854, 444);
            this.lbl_NamaCategory.Name = "lbl_NamaCategory";
            this.lbl_NamaCategory.Size = new System.Drawing.Size(74, 25);
            this.lbl_NamaCategory.TabIndex = 7;
            this.lbl_NamaCategory.Text = "Nama:";
            // 
            // tBox_NamaCategory
            // 
            this.tBox_NamaCategory.Location = new System.Drawing.Point(970, 438);
            this.tBox_NamaCategory.Name = "tBox_NamaCategory";
            this.tBox_NamaCategory.Size = new System.Drawing.Size(287, 31);
            this.tBox_NamaCategory.TabIndex = 8;
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.Location = new System.Drawing.Point(1015, 490);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(118, 75);
            this.btn_AddCategory.TabIndex = 9;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = true;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.Location = new System.Drawing.Point(1139, 490);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(118, 75);
            this.btn_RemoveCategory.TabIndex = 10;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = true;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // lbl_Details
            // 
            this.lbl_Details.AutoSize = true;
            this.lbl_Details.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details.Location = new System.Drawing.Point(43, 563);
            this.lbl_Details.Name = "lbl_Details";
            this.lbl_Details.Size = new System.Drawing.Size(126, 42);
            this.lbl_Details.TabIndex = 11;
            this.lbl_Details.Text = "Details";
            // 
            // lbl_NamaDetails
            // 
            this.lbl_NamaDetails.AutoSize = true;
            this.lbl_NamaDetails.Location = new System.Drawing.Point(45, 623);
            this.lbl_NamaDetails.Name = "lbl_NamaDetails";
            this.lbl_NamaDetails.Size = new System.Drawing.Size(74, 25);
            this.lbl_NamaDetails.TabIndex = 12;
            this.lbl_NamaDetails.Text = "Nama:";
            // 
            // lbl_CategoryDetails
            // 
            this.lbl_CategoryDetails.AutoSize = true;
            this.lbl_CategoryDetails.Location = new System.Drawing.Point(14, 663);
            this.lbl_CategoryDetails.Name = "lbl_CategoryDetails";
            this.lbl_CategoryDetails.Size = new System.Drawing.Size(105, 25);
            this.lbl_CategoryDetails.TabIndex = 13;
            this.lbl_CategoryDetails.Text = "Category:";
            // 
            // lbl_HargaDetails
            // 
            this.lbl_HargaDetails.AutoSize = true;
            this.lbl_HargaDetails.Location = new System.Drawing.Point(43, 704);
            this.lbl_HargaDetails.Name = "lbl_HargaDetails";
            this.lbl_HargaDetails.Size = new System.Drawing.Size(76, 25);
            this.lbl_HargaDetails.TabIndex = 14;
            this.lbl_HargaDetails.Text = "Harga:";
            // 
            // lbl_StockDetails
            // 
            this.lbl_StockDetails.AutoSize = true;
            this.lbl_StockDetails.Location = new System.Drawing.Point(43, 745);
            this.lbl_StockDetails.Name = "lbl_StockDetails";
            this.lbl_StockDetails.Size = new System.Drawing.Size(72, 25);
            this.lbl_StockDetails.TabIndex = 15;
            this.lbl_StockDetails.Text = "Stock:";
            // 
            // tBox_NamaDetails
            // 
            this.tBox_NamaDetails.Location = new System.Drawing.Point(144, 620);
            this.tBox_NamaDetails.Name = "tBox_NamaDetails";
            this.tBox_NamaDetails.Size = new System.Drawing.Size(612, 31);
            this.tBox_NamaDetails.TabIndex = 16;
            // 
            // comboBox_CategoryDetails
            // 
            this.comboBox_CategoryDetails.FormattingEnabled = true;
            this.comboBox_CategoryDetails.Location = new System.Drawing.Point(144, 660);
            this.comboBox_CategoryDetails.Name = "comboBox_CategoryDetails";
            this.comboBox_CategoryDetails.Size = new System.Drawing.Size(177, 33);
            this.comboBox_CategoryDetails.TabIndex = 17;
            // 
            // tBox_HargaDetails
            // 
            this.tBox_HargaDetails.Location = new System.Drawing.Point(144, 701);
            this.tBox_HargaDetails.Name = "tBox_HargaDetails";
            this.tBox_HargaDetails.Size = new System.Drawing.Size(177, 31);
            this.tBox_HargaDetails.TabIndex = 18;
            this.tBox_HargaDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_HargaDetails_KeyPress);
            // 
            // tBox_StockDetails
            // 
            this.tBox_StockDetails.Location = new System.Drawing.Point(144, 742);
            this.tBox_StockDetails.Name = "tBox_StockDetails";
            this.tBox_StockDetails.Size = new System.Drawing.Size(177, 31);
            this.tBox_StockDetails.TabIndex = 19;
            this.tBox_StockDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_HargaDetails_KeyPress);
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.Location = new System.Drawing.Point(364, 692);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(118, 69);
            this.btn_AddProduct.TabIndex = 20;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = true;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.Location = new System.Drawing.Point(488, 692);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(118, 69);
            this.btn_EditProduct.TabIndex = 21;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = true;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.Location = new System.Drawing.Point(612, 692);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(118, 69);
            this.btn_RemoveProduct.TabIndex = 22;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = true;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // pictureBox_Molang
            // 
            this.pictureBox_Molang.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Molang.Image")));
            this.pictureBox_Molang.Location = new System.Drawing.Point(884, 490);
            this.pictureBox_Molang.Name = "pictureBox_Molang";
            this.pictureBox_Molang.Size = new System.Drawing.Size(440, 394);
            this.pictureBox_Molang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Molang.TabIndex = 23;
            this.pictureBox_Molang.TabStop = false;
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1324, 835);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.tBox_StockDetails);
            this.Controls.Add(this.tBox_HargaDetails);
            this.Controls.Add(this.comboBox_CategoryDetails);
            this.Controls.Add(this.tBox_NamaDetails);
            this.Controls.Add(this.lbl_StockDetails);
            this.Controls.Add(this.lbl_HargaDetails);
            this.Controls.Add(this.lbl_CategoryDetails);
            this.Controls.Add(this.lbl_NamaDetails);
            this.Controls.Add(this.lbl_Details);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.tBox_NamaCategory);
            this.Controls.Add(this.lbl_NamaCategory);
            this.Controls.Add(this.dataGridView_Category);
            this.Controls.Add(this.lbl_Category);
            this.Controls.Add(this.comboBox_BuatFilter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.dataGridView_Product);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.lbl_Product);
            this.Controls.Add(this.pictureBox_Molang);
            this.Name = "Shop";
            this.Text = "ShopView";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Molang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Product;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.DataGridView dataGridView_Product;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox comboBox_BuatFilter;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.DataGridView dataGridView_Category;
        private System.Windows.Forms.Label lbl_NamaCategory;
        private System.Windows.Forms.TextBox tBox_NamaCategory;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.Label lbl_Details;
        private System.Windows.Forms.Label lbl_NamaDetails;
        private System.Windows.Forms.Label lbl_CategoryDetails;
        private System.Windows.Forms.Label lbl_HargaDetails;
        private System.Windows.Forms.Label lbl_StockDetails;
        private System.Windows.Forms.TextBox tBox_NamaDetails;
        private System.Windows.Forms.ComboBox comboBox_CategoryDetails;
        private System.Windows.Forms.TextBox tBox_HargaDetails;
        private System.Windows.Forms.TextBox tBox_StockDetails;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.PictureBox pictureBox_Molang;
    }
}

